<template>
  <section>
    <ul class="job-list">
      <JobDetails
        v-for="job in jobs"
        :key="job.id"
        :job="job"
      />
    </ul>
  </section>
</template>

<script>
import api from '@/utils/Axios';
import JobDetails from './JobDetails.vue';

export default {
  components: {
    JobDetails // Register the JobDetails component
  },
  data() {
    return {
      jobs: [] // Array to hold job data
    };
  },
  mounted() {
    this.fetchJobs(); // Fetch job data when the component is mounted
  },
  methods: {
    async fetchJobs() {
      try {
        // Fetch job data from the API
        const response = await api.get('/employee/job-list');
        this.jobs = response.data; // Assign the job data to the component's state
      } catch (error) {
        console.error('Error fetching jobs', error); // Log any errors
      }
    }
  }
}
</script>

<style scoped>
section {
  margin: 2rem auto;
  max-width: 1200px; /* Adjust based on desired width */
  padding: 1rem;
}

.job-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); /* Auto-fit cards with a minimum size */
  gap: 1rem; /* Same spacing between cards horizontally and vertically */
  list-style: none;
  padding: 0;
  margin: 0;
}

.job-card {
  background: #ffffff;
  border: 1px solid #ddd;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  padding: 1rem;
  box-sizing: border-box; /* Ensure padding and border are included in the width */
  transition: box-shadow 0.3s ease;
}

.job-card:hover {
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
}

.job-title {
  margin: 0 0 0.5rem 0;
  font-size: 1.25rem;
  color: #333;
}

.job-role, .job-openings {
  margin: 0;
  color: #666;
}

.btn {
  display: inline-block;
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.btn-dark {
  background-color: #333;
  color: #fff;
}
</style>
