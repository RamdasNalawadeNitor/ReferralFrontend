<template>
  <li class="job-card">
    <h3 class="job-title">{{ job.title }}</h3>
    <p class="job-role">Role: {{ job.title }}</p>
    <p class="job-role">Job Id: {{ job.id }}</p>
    <p class="job-openings">Number of Openings: {{ job.numOpenings }}</p>
    <button type="submit" class="btn btn-dark" @click="referCandidate" ref="">Refer a candidate</button> &nbsp;
    <button type="submit" class="btn btn-dark" @click="getDetails(job.id)" ref="">View Details</button>
</li>
</template>

<script>
export default {
  components: {  },
  props: { 
    job: {
      type: Object,
      required: true,
    }   
  },
  methods:
  {
    referCandidate()
    {
      this.$router.push('/emp/joblist/register');
    },
    async getDetails(jobId)
    {
        this.$router.push(`/emp/viewdetails/${jobId}`);
      
    }
  }
}
</script>

<style scoped>
.job-card {
  background: #ffffff;
  border: 1px solid #ddd;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  margin-bottom: 1rem;
  padding: 1rem;
  transition: box-shadow 0.3s ease;
}

.job-card:hover {
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
}

.job-title {
  margin: 0 0 0.5rem 0;
  font-size: 1.25rem;
  color: #333;
}

.job-role, .job-openings {
  margin: 0;
  color: #666;
}
</style>
