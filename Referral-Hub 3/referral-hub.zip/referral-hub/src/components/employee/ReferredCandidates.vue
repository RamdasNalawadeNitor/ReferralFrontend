<template>
  <div class="table-container">
    <h1>List of Referred Candidates</h1>
    <table v-if="candidates.length">
      <thead>
        <tr>
          <th>Name</th>
          <th>Status</th>
          <th>Applied Job</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="candidate in candidates" :key="candidate.id">
          <td>{{ candidate.name }}</td>
          <td>{{ candidate.status }}</td>
          <td>
            <ul>
              <li v-for="(job, index) in candidate.appliedJob" :key="index">
                {{ job.title }}
              </li>
            </ul>
          </td>
        </tr>
      </tbody>
    </table>
    <p v-else>No referred candidates found.</p>
  </div>
</template>

<script>
import api from '@/utils/Axios';
import store from '@/store';

export default {
  data() {
    return {
      candidates: [],
      EmpId: store.state.EmpId, // Ensure you're using the correct key from the store
    };
  },
  created() {
    this.fetchReferredCandidates();
  },
  methods: {
    async fetchReferredCandidates() {
      if (this.EmpId) {
        try {
          const response = await api.get(`/employee/getReferredCandidates/${this.EmpId}`);
          console.log('API Response:', response.data); // Log the response data for debugging
          if (response.data && Array.isArray(response.data)) {
            this.candidates = response.data;
          } else {
            console.error('Invalid response format:', response.data);
          }
        } catch (error) {
          console.error('Error fetching referred candidates:', error);
        }
      } else {
        console.error('Employee ID is not set.');
      }
    },
  },
};
</script>

<style scoped>
.table-container {
  max-width: 1000px; /* Adjust to fit your design */
  margin: 0 auto;
  padding: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin: 0 auto; /* Center the table within the container */
}

th, td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left; /* Align text to the left */
}

th {
  background-color: #f4f4f4;
}

ul {
  padding: 0;
  margin: 0;
  list-style-type: none;
}

li {
  padding: 5px 0;
}
</style>
