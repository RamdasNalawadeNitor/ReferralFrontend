<template>
  <header>
    <div class="container">
      <nav>
        <ul>
          <li class="nav-item">
            <router-link to="/" class="nav-link" exact active-class="active-link" exact-active-class="active-link">
              <h2>ReferrelHub</h2>
            </router-link>
          </li>
          <!-- <li class="nav-item">
            <div class="input-container">
              <input type="text" v-model="search" placeholder="Search by first name">
            </div>
          </li> -->
          <li v-if="isAdmin" class="nav-item">
            <router-link to="/emps/approved" class="nav-link" active-class="active-link">Approved Employees</router-link>
          </li>
          <li v-if="isAdmin" class="nav-item">
            <router-link to="/emps/pending" class="nav-link" active-class="active-link">Pending Approvals</router-link>
          </li>
          <li v-if="isEmployee" class="nav-item">
            <router-link to="/emp/joblist" class="nav-link" active-class="active-link">Job Openings</router-link>
          </li>
          <li v-if="isEmployee" class="nav-item">
            <router-link :to="`/emp/referredcandidates/${userId}`" class="nav-link" active-class="active-link">Referred Candidates</router-link>
          </li>
          <li v-if="isHr" class="nav-item">
            <router-link to="/jobs" class="nav-link" active-class="active-link">Job List</router-link>
          </li>
          <li v-if="isHr" class="nav-item">
            <router-link to="/jobs/register" class="nav-link" active-class="active-link" @click="postJob">Post Job</router-link>
          </li>
          <li v-if="isHr" class="nav-item">
            <router-link to="/jobs/closed" class="nav-link" active-class="active-link" @click="closedJobs">Closed Jobs</router-link>
          </li>
          <li v-if="isAdmin || isEmployee || isHr" class="nav-item">
            <router-link to="/" class="nav-link" id="signout" active-class="signout-active" @click="signOut">Sign Out</router-link>
          </li>
        </ul>
      </nav>
    </div>
  </header>
</template>

<script>
import store from '@/store';

export default {
  data() {
    return {
      search: '',
      employees: [],
    };
  },
  computed: {
    isAdmin() {
      return store.state.roles.includes('ROLE_ADMIN');
    },
    isEmployee() {
      return store.state.roles.includes('ROLE_EMPLOYEE');
    },
    isHr() {
      return store.state.roles.includes('ROLE_HR');
    },
    userId() {
      return store.state.userId;
    },
    filteredEmployees() {
      return this.employees.filter(emp =>
        emp.firstName.toLowerCase().includes(this.search.toLowerCase())
      );
    },
  },
  methods: {
    postJob() {
      this.$router.push('/jobs/register');
    },
    closedJobs() {
      this.$router.push('/jobs/closed');
    },
    signOut() {
      localStorage.removeItem('token');
      this.$router.push('/').then(() => {
        window.location.reload();
      });
    },
  },
};
</script>

<style scoped>
header {
  width: 100%;
  height: 5rem;
  background-color: black;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
}

nav {
  height: 100%;
  display: flex;
  align-items: center; /* Center items vertically */
}

ul {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  align-items: center; /* Align items vertically in the middle */
  width: 100%;
}

.nav-item {
  margin: 0 0.5rem; /* Space between items */
}

.nav-link {
  text-decoration: none;
  background: transparent;
  border: 1px solid transparent;
  cursor: pointer;
  color: white;
  padding: 0.5rem 1rem;
}

.input-container {
  display: flex;
  align-items: center; /* Align input field vertically with other items */
  margin-left: auto; /* Pushes input field to the right */
}

input[type="text"] {
  padding: 10px 15px;
  font-size: 16px;
  border: 2px solid #ddd;
  border-radius: 20px;
  width: 250px;
  background-color: #f0f0f0;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  outline: none;
  transition: all 0.3s ease;
}

input[type="text"]:focus {
  border-color: #007bff;
  background-color: white;
  box-shadow: 0 0 8px rgba(0, 123, 255, 0.5);
}

.nav-link:hover {
  background-color: grey;
}

.active-link {
  background-color: grey;
  color: white;
}

#signout {
  margin-left: auto; /* Align Sign Out link to the far right */
}
</style>
