import { reactive } from 'vue';
import { getRolesFromToken } from '../utils/auth';
import { getEmpId } from '../utils/auth';
 
const state = reactive({
  token: localStorage.getItem('token') || null,
  roles: getRolesFromToken(localStorage.getItem('token')) || [],
 EmpId: getEmpId(localStorage.getItem('token')) || null,
});
 
 
const setToken = (token) => {
  state.token = token;
  state.roles = getRolesFromToken(token);
  state.EmpId=getEmpId(token);
  localStorage.setItem('token', token);
 
};
 
export function clearToken (){
  state.token = null;
  state.roles = [];
  state.EmpId = null;
  localStorage.removeItem('token');
 
}
 
export default {
  state,
  setToken,
  clearToken,
};