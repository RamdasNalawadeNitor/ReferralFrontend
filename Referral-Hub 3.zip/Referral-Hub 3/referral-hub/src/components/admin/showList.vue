<template>
  <employee-list></employee-list>
</template>

<script>
import EmployeeList from './EmployeeList.vue';

export default {
    components:{EmployeeList}
}
</script>

<style>

</style>